cars = {
    1: {
        "make": "Audi",
        "model": "A5",
        "year": 2018,
        "price": 250000.0,
        "engine": "V7",
        "autonomous": False,
        "sold": ["NA","EU","IND"]
    },

    2: {
        "make": "Fortuner",
        "model": "FourWheeler SUV",
        "year": 2021,
        "price": 55400.0,
        "engine": "V4",
        "autonomous": False,
        "sold": ["AF","AN","AS","EU","NA","OC","SA"]
    },

    3: {
        "make": "BMW",
        "model": "SuperCar",
        "year": 2019,
        "price": 45000.0,
        "engine": "V8",
        "autonomous": True,
        "sold": ["AS","OC"]
    },

    4: {
        "make": "Mercedes",
        "model": "Beetle",
        "year": 2004,
        "price": 21299.99,
        "engine": "V4",
        "autonomous": False,
        "sold": ["AS","AF","OC"]
    },

    5: {
        "make": "Jaguar",
        "model": "Supersonic",
        "year": 2015,
        "price": 215000.0,
        "engine": "V12",
        "autonomous": False,
        "sold": ["NA","AF","OC","SA"]
    }
}